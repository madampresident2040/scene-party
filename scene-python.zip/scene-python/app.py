"""Scene — Flask server. Serves the web/ frontend and the JSON API.
Run:  python app.py   →  http://localhost:3000"""

import json
import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

from flask import Flask, jsonify, request, send_from_directory  # noqa: E402

from backend import pipeline  # noqa: E402
from backend.band_client import band_configured  # noqa: E402
from backend.insforge_client import insforge_configured, set_task_completed  # noqa: E402

WEB_DIR = Path(__file__).parent / "web"
ALLOWED_MIMES = {"image/jpeg", "image/png", "image/webp"}

app = Flask(__name__, static_folder=str(WEB_DIR), static_url_path="")
app.config["MAX_CONTENT_LENGTH"] = 12 * 1024 * 1024  # 12 MB


def public_project(p):
    """Public view of a project — everything the dashboard renders."""
    if not p:
        return None
    return {k: v for k, v in p.items() if k != "original_image_key"}


@app.get("/")
def index():
    return send_from_directory(WEB_DIR, "index.html")


@app.get("/api/health")
def health():
    return jsonify({
        "ok": True,
        "demoMode": pipeline.demo_mode(),
        "insforge": insforge_configured(),
        "band": band_configured(),
    })


@app.get("/api/demo")
def demo():
    return jsonify(public_project(pipeline.get_project("demo")))


@app.post("/api/projects")
def create_project():
    try:
        try:
            prefs = json.loads(request.form.get("prefs") or "{}")
        except ValueError:
            prefs = {}

        def clamp(value, lo, hi, default):
            try:
                n = float(value)
            except (TypeError, ValueError):
                n = default
            return max(lo, min(hi, n))

        prefs = {
            "party_type": str(prefs.get("party_type") or "Birthday"),
            "theme": str(prefs.get("theme") or "")[:200],
            "style": str(prefs.get("style") or "Elegant"),
            "colors": [str(c) for c in prefs.get("colors", [])[:6]] if isinstance(prefs.get("colors"), list) else [],
            "guest_count": int(clamp(prefs.get("guest_count"), 1, 500, 20)),
            "budget": clamp(prefs.get("budget"), 20, 100000, 200),
            "event_date": prefs.get("event_date") or None,
            "setting": "outdoor" if prefs.get("setting") == "outdoor" else "indoor",
            "wants": str(prefs.get("wants") or "")[:500],
            "avoids": str(prefs.get("avoids") or "")[:500],
            "notes": str(prefs.get("notes") or "")[:1000],
        }

        photo = request.files.get("room")
        if photo and photo.mimetype not in ALLOWED_MIMES:
            return jsonify({"error": "Please upload a JPG, PNG, or WebP photo of your room."}), 400
        if not pipeline.demo_mode() and not photo:
            return jsonify({"error": "Add a photo of your room to get started."}), 400

        project = pipeline.create_project(
            image_bytes=photo.read() if photo else None,
            image_mime=photo.mimetype if photo else None,
            prefs=prefs,
        )
        return jsonify(public_project(project))
    except Exception as err:  # noqa: BLE001
        print(f"[API] create project failed: {err}", flush=True)
        return jsonify({
            "error": "Something went wrong starting your party. Try again, or open the demo experience."
        }), 500


@app.get("/api/projects/<project_id>")
def get_project(project_id):
    p = pipeline.get_project(project_id)
    if not p:
        return jsonify({"error": "Project not found. It may have expired — start a new one."}), 404
    return jsonify(public_project(p))


@app.post("/api/projects/<project_id>/tasks/<task_id>")
def toggle_task(project_id, task_id):
    completed = bool((request.get_json(silent=True) or {}).get("completed"))
    task = pipeline.toggle_task(project_id, task_id, completed)
    if not task:
        return jsonify({"error": "Task not found."}), 404
    if project_id != "demo" and insforge_configured():
        try:
            set_task_completed(task_id, completed)
        except Exception as err:  # noqa: BLE001
            print(f"[API] task save skipped: {err}", flush=True)
    return jsonify(task)


@app.post("/api/projects/<project_id>/budget")
def budget(project_id):
    """Budget controls — deterministic filtering, recomputed server-side."""
    p = pipeline.get_project(project_id)
    if not p:
        return jsonify({"error": "Project not found."}), 404
    action = str((request.get_json(silent=True) or {}).get("action") or "")
    products = [dict(x) for x in p["products"]]

    if action == "essentials":
        for x in products:
            x["hidden"] = not x.get("essential")
    elif action == "fewer":
        keep = {x["id"] for x in products if x.get("essential")}
        optional = sorted(
            [x for x in products if not x.get("essential")],
            key=lambda x: x.get("matchScore", 0),
            reverse=True,
        )
        keep.update(x["id"] for x in optional[:2])
        for x in products:
            x["hidden"] = x["id"] not in keep
    elif action == "under_budget":
        ordered = sorted(
            products,
            key=lambda x: (bool(x.get("essential")), x.get("matchScore", 0)),
            reverse=True,
        )
        running, keep = 0.0, set()
        for x in ordered:
            price = float(x.get("estimatedPrice") or 0)
            if running + price <= float(p.get("budget") or 0) or (x.get("essential") and not keep):
                keep.add(x["id"])
                running += price
        for x in products:
            x["hidden"] = x["id"] not in keep
    elif action == "replace_expensive":
        visible = [x for x in products if not x.get("hidden")]
        cap = max(15.0, float(p.get("budget") or 0) / max(4, len(visible)))
        for x in products:
            if float(x.get("estimatedPrice") or 0) > cap and not x.get("essential"):
                x["hidden"] = True
    elif action == "reset":
        for x in products:
            x["hidden"] = False
    else:
        return jsonify({"error": "Unknown budget action."}), 400

    p["products"] = products
    visible = [x for x in products if not x.get("hidden")]

    def total(items):
        return round(sum(float(x.get("estimatedPrice") or 0) for x in items), 2)

    p["essential_subtotal"] = total([x for x in visible if x.get("essential")])
    p["optional_subtotal"] = total([x for x in visible if not x.get("essential")])
    p["estimated_total"] = round(p["essential_subtotal"] + p["optional_subtotal"], 2)
    return jsonify(public_project(p))


@app.errorhandler(413)
def too_large(_err):
    return jsonify({"error": "That photo is too large — please use one under 12 MB."}), 413


@app.errorhandler(Exception)
def friendly_error(err):
    print(f"[API] error: {err}", flush=True)
    return jsonify({"error": str(err) or "Something went wrong."}), 400


if __name__ == "__main__":
    port = int(os.getenv("PORT", "3000"))
    print(f"\n  Scene is running → http://localhost:{port}")
    print(f"  Demo mode: {'ON (bundled sample data)' if pipeline.demo_mode() else 'off'}")
    print(f"  InsForge:  {'connected' if insforge_configured() else 'not configured'}")
    print(f"  Band:      {'enabled' if band_configured() else 'disabled (local fallback)'}\n")
    app.run(host="0.0.0.0", port=port, debug=False, threaded=True)
