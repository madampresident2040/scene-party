-- Scene schema for InsForge (Postgres).
-- Apply with the InsForge CLI after `npx @insforge/cli login && npx @insforge/cli link`
-- (the CLI's db skill can run this file as a migration).
-- Storage buckets needed (create as PUBLIC so the Model Gateway can read image URLs):
--   room-images, generated-images

create extension if not exists pgcrypto;

create table if not exists party_projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  party_type text,
  theme text,
  colors jsonb default '[]',
  guest_count integer,
  budget numeric,
  event_date date,
  additional_notes text,
  original_image_url text,
  generated_image_url text,
  room_analysis jsonb,
  visual_inventory jsonb,
  estimated_total numeric default 0,
  status text default 'processing',
  created_at timestamptz default now()
);

create table if not exists party_products (
  id uuid primary key default gen_random_uuid(),
  project_id uuid references party_projects(id) on delete cascade,
  item_name text,
  category text,
  search_query text,
  amazon_url text,
  estimated_price numeric,
  quantity integer default 1,
  match_score integer,
  essential boolean default false,
  reasoning text
);

create table if not exists party_tasks (
  id uuid primary key default gen_random_uuid(),
  project_id uuid references party_projects(id) on delete cascade,
  task text,
  category text,
  due_date date,
  completed boolean default false,
  sort_order integer default 0
);
