"""Band integration. The server holds the API key of the "Scene Orchestrator",
a remote agent registered at https://app.band.ai/agents. It uses ONLY
documented Band Agent API endpoints (docs.band.ai/api/agent-api):

  POST /api/v1/agent/chats/:chat_id/messages         → send @mention message
  GET  /api/v1/agent/chats/:chat_id/messages/next    → oldest unprocessed message
  POST /api/v1/agent/chats/:chat_id/messages/:id/processing
  POST /api/v1/agent/chats/:chat_id/messages/:id/processed
  POST /api/v1/agent/chats/:chat_id/messages/:id/failed

The five specialist agents run separately (band_agents/agents.py) on the
Band SDK AnthropicAdapter. They wake on @mention, reason, and reply
"@SceneOrchestrator [marker] { ...json }". The orchestrator collects replies
through the documented next/processing/processed queue workflow."""

import os
import re
import time

import requests

_TIMEOUT = 30

_ROLE_ENV = {
    "analyst": ("BAND_ANALYST_ID", "BAND_ANALYST_NAME"),
    "designer": ("BAND_DESIGNER_ID", "BAND_DESIGNER_NAME"),
    "inventory": ("BAND_INVENTORY_ID", "BAND_INVENTORY_NAME"),
    "shopper": ("BAND_SHOPPER_ID", "BAND_SHOPPER_NAME"),
    "planner": ("BAND_PLANNER_ID", "BAND_PLANNER_NAME"),
}


def _rest():
    return (os.getenv("BAND_REST_URL") or "https://app.band.ai").rstrip("/")


def _key():
    return os.getenv("BAND_ORCHESTRATOR_API_KEY") or ""


def _room():
    return os.getenv("BAND_ROOM_ID") or ""


def _stage_timeout():
    return float(os.getenv("BAND_STAGE_TIMEOUT") or 90)


def band_configured():
    return (
        str(os.getenv("BAND_ENABLED")).lower() == "true"
        and bool(_key())
        and bool(_room())
    )


def band_agent(role):
    id_key, name_key = _ROLE_ENV[role]
    agent_id = os.getenv(id_key)
    name = os.getenv(name_key) or role
    if not agent_id:
        raise RuntimeError(f"[Band] missing {id_key} in .env")
    return {"id": agent_id, "name": name}


def _band(method, path, json_body=None):
    resp = requests.request(
        method,
        f"{_rest()}{path}",
        headers={"X-API-Key": _key(), "Content-Type": "application/json"},
        json=json_body,
        timeout=_TIMEOUT,
    )
    if resp.status_code == 204:
        return None
    try:
        body = resp.json()
    except ValueError:
        body = {}
    if not resp.ok:
        raise RuntimeError(f"[Band] {method} {path} → {resp.status_code}: {body}")
    return body


def send_to_agent(agent, content):
    """Send a message into the Scene room, @mentioning one specialist agent."""
    out = _band(
        "POST",
        f"/api/v1/agent/chats/{_room()}/messages",
        {
            "message": {
                "content": f"@{agent['name']} {content}",
                "mentions": [{"id": agent["id"], "name": agent["name"]}],
            }
        },
    )
    msg_id = ((out or {}).get("data") or {}).get("id", "?")
    print(f"[Band] → @{agent['name']} (message {msg_id})", flush=True)
    return (out or {}).get("data")


def await_agent_reply(marker):
    """Orchestrator work loop: poll the documented queue until the specialist's
    reply (a message @mentioning the orchestrator) arrives, then ack it."""
    deadline = time.time() + _stage_timeout()
    room = _room()
    while time.time() < deadline:
        nxt = _band("GET", f"/api/v1/agent/chats/{room}/messages/next")
        msg = (nxt or {}).get("data")
        if msg:
            _band("POST", f"/api/v1/agent/chats/{room}/messages/{msg['id']}/processing")
            content = str(msg.get("content") or "")
            relevant = (not marker) or (marker in content)
            try:
                _band("POST", f"/api/v1/agent/chats/{room}/messages/{msg['id']}/processed")
                if relevant:
                    sender = msg.get("sender_name") or msg.get("sender_id")
                    print(f"[Band] ← reply from {sender}", flush=True)
                    return content
                # Stale/unrelated message acked above so the queue keeps moving.
            except Exception as err:
                try:
                    _band(
                        "POST",
                        f"/api/v1/agent/chats/{room}/messages/{msg['id']}/failed",
                        {"error": str(err)},
                    )
                except Exception:
                    pass
                raise
        else:
            time.sleep(2.5)
    raise TimeoutError(f"[Band] timed out after {_stage_timeout():.0f}s waiting for a specialist reply")


def run_band_stage(role, payload, marker):
    """One full Band stage: dispatch work to a specialist, await its JSON reply.
    Each dispatch carries a run marker the specialist must echo, so parallel
    projects sharing the room never cross wires."""
    agent = band_agent(role)
    send_to_agent(
        agent,
        f"{payload}\n\nWhen finished, reply in this room mentioning @SceneOrchestrator, "
        f"include the marker {marker} on the first line, then ONLY your JSON result.",
    )
    reply = await_agent_reply(marker)
    return re.sub(r"@\S+", "", reply.replace(marker, "")).strip()
