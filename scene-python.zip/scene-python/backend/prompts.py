"""Every prompt used by the pipeline, whether a stage runs through a Band agent
or through the InsForge Model Gateway local fallback. JSON-only discipline
everywhere so results are machine-usable."""

import json
import re

JSON_ONLY = (
    "Respond with ONLY a valid JSON object or array. "
    "No markdown fences, no preamble, no commentary."
)


def room_vision_prompt():
    return """You are analyzing a photo of a real room where a party will be hosted.
Describe factually and thoroughly: room type, approximate layout and dimensions,
each visible wall, existing furniture and its positions, open surfaces suitable
for decorating, the widest uninterrupted wall (candidate backdrop location),
where a balloon arch could anchor, table locations, lighting conditions,
obstructions, and any safety or feasibility concerns. Plain text, precise,
no decoration ideas yet."""


def room_analysis_prompt(vision_description):
    return f"""{JSON_ONLY}
You are the Scene Room Analysis Agent. Convert this factual room description into
structured room-analysis JSON with EXACTLY these keys:
roomType, approximateLayout, visibleWalls (array), existingFurniture (array),
decoratingSurfaces (array), backdropLocation, balloonArchLocation,
tableLocations (array), lightingConditions, obstructions (array),
safetyConcerns (array), recommendedStrategy.

Room description:
{vision_description}"""


def design_plan_prompt(room_analysis, prefs):
    return f"""{JSON_ONLY}
You are the Scene Party Designer Agent. Create a decoration plan for THIS room
that is realistic and purchasable — not a fantasy set.
Return JSON with keys: partyName (short, evocative), designExplanation (2 sentences,
must reference actual room features from the analysis), colorPalette (array of 3-4 hex),
paletteNames (array matching the hexes), focalPoint, decorationList (array of 6-10 short
decoration descriptions placed at real locations from the analysis).

Room analysis: {json.dumps(room_analysis)}
Party preferences: {json.dumps(prefs)}"""


def image_edit_prompt(prefs, design_plan):
    """The image-edit prompt REQUIRED by the product spec, enriched with the plan."""
    design_plan = design_plan or {}
    wants = f" Include: {prefs['wants']}." if prefs.get("wants") else ""
    avoid = f" Do not include: {prefs['avoids']}." if prefs.get("avoids") else ""
    return (
        "Edit this uploaded room into a completed party setup. Preserve the room\u2019s "
        "architecture, perspective, camera angle, walls, flooring, windows, doors, and "
        "recognizable furniture. Add realistic, purchasable decorations matching the "
        "requested party theme, colors, budget, and guest count. Do not replace the room "
        "with a different venue. "
        f"Theme: {prefs.get('theme') or prefs.get('party_type')}. "
        f"Style: {prefs.get('style') or 'elegant'}. "
        f"Colors: {', '.join(prefs.get('colors') or [])}. "
        f"Guests: {prefs.get('guest_count')}. "
        f"Budget: ${prefs.get('budget')}. "
        f"Design direction: {design_plan.get('designExplanation') or ''} "
        f"Decorations to add: {'; '.join(design_plan.get('decorationList') or [])}."
        + wants
        + avoid
        + " The result must look like an achievable real-world party setup."
    )


def generated_image_vision_prompt():
    return """You are looking at an AI-generated visualization of a decorated party room.
List every visible major decoration item factually: what it is, its main and secondary
colors, style, material if visible, approximate size, approximate quantity, and where
in the room it appears. Plain text, one item per line, exhaustive."""


def visual_inventory_prompt(decor_description, prefs):
    return f"""{JSON_ONLY}
You are the Scene Visual Inventory Agent. Convert this description of decorations
visible in a generated party-room image into a structured visual inventory.
Return a JSON array of 8-12 items, each with EXACTLY these keys:
name, category (one of: "Backdrop and focal area", "Balloons and wall decor",
"Tablescape", "Lighting", "Cake and dessert table", "Party favors", "Optional upgrades"),
colors (array), style, material, approximateSize, estimatedQuantity (number),
searchQuery (a precise Amazon search phrase with colors + item + size/count —
never vague like "party decoration"), importance ("essential" or "optional"),
roomLocation.

Only include items that appear in the description. Party context: {json.dumps(prefs)}

Decorations visible in the generated image:
{decor_description}"""


def product_match_prompt(inventory, prefs):
    return f"""{JSON_ONLY}
You are the Scene Shopping Match Agent. For each inventory item, estimate a realistic
Amazon price in USD and score how well a top search result for its searchQuery would
match the generated design. matchScore is 0-100 weighing: color similarity, category
match, style match, size suitability, budget fit (total budget ${prefs.get('budget')}),
and importance to the final design. Add a one-sentence reasoning that references the
generated room. Return the SAME array with these keys added to every item:
estimatedPrice (number), matchScore (integer), reasoning.
Keep the essential items' total comfortably under budget when possible.

Inventory: {json.dumps(inventory)}"""


def setup_plan_prompt(room_analysis, design_plan, products):
    names = [p.get("name") for p in products]
    return f"""{JSON_ONLY}
You are the Scene Setup Planner Agent. Produce room-specific instructions that
reference the ACTUAL room features and the ACTUAL products (e.g. "Place the shimmer
backdrop against the back wall shown behind the sofa" — never generic "set up the
backdrop"). Return JSON with two keys:
"setupGuide": array of steps {{ step (number), instruction, estimatedTime, requiredProducts (array of product names), helpers (number) }}
"checklist": array of 10-14 external planning tasks {{ task, category, sort_order (number) }}
covering guest list, cake, food, music, games, ice, camera, clearing the room,
balloon inflation, backdrop install, tables, favors, and cleanup.

Room analysis: {json.dumps(room_analysis)}
Design plan: {json.dumps(design_plan)}
Products: {json.dumps(names)}"""


def parse_json_loose(text):
    """Strip accidental markdown fences and parse JSON defensively."""
    if not isinstance(text, str):
        return text
    t = text.strip()
    t = re.sub(r"^```(?:json)?", "", t, flags=re.IGNORECASE).strip()
    t = re.sub(r"```$", "", t).strip()
    firsts = [i for i in (t.find("{"), t.find("[")) if i != -1]
    if firsts and min(firsts) > 0:
        t = t[min(firsts):]
    last = max(t.rfind("}"), t.rfind("]"))
    if last != -1:
        t = t[: last + 1]
    return json.loads(t)
