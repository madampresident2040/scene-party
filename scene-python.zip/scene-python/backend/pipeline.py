"""The Scene planning pipeline. Perception (seeing images) runs on the InsForge
Model Gateway; reasoning stages run as Band agents when BAND_ENABLED=true,
with a local Model Gateway fallback per stage so one failure never blanks
the result screen. DEMO_MODE bypasses everything with labeled sample data."""

import copy
import json
import os
import threading
import uuid
from pathlib import Path

from . import band_client, insforge_client
from .amazon import with_amazon_links
from .prompts import (
    design_plan_prompt, generated_image_vision_prompt, image_edit_prompt,
    parse_json_loose, product_match_prompt, room_analysis_prompt,
    room_vision_prompt, setup_plan_prompt, visual_inventory_prompt,
)

_DEMO_JSON = Path(__file__).with_name("demo_data.json")


def demo_mode():
    return str(os.getenv("DEMO_MODE", "true")).lower() != "false"


# In-memory project map keeps the demo resilient even if the DB write fails.
_projects = {}
_lock = threading.Lock()

STAGE_DEFS = [
    {"key": "room_analysis", "label": "Understanding the space", "done": "Room analyzed", "agent": "SceneAnalyst"},
    {"key": "design_plan", "label": "Designing your party", "done": "Design created", "agent": "SceneDesigner"},
    {"key": "image_generation", "label": "Generating your party vision", "done": "Party vision generated", "agent": "InsForge Model Gateway"},
    {"key": "visual_inventory", "label": "Identifying decorations", "done": "Decorations identified", "agent": "SceneInventory"},
    {"key": "product_matching", "label": "Finding matching products", "done": "Products matched", "agent": "SceneShopper"},
    {"key": "setup_plan", "label": "Building your setup plan", "done": "Setup plan generated", "agent": "ScenePlanner"},
]


def build_demo_project():
    with open(_DEMO_JSON, encoding="utf-8") as f:
        return json.load(f)


def get_project(project_id):
    with _lock:
        if project_id == "demo":
            if "demo" not in _projects:
                _projects["demo"] = build_demo_project()
            return _projects["demo"]
        return _projects.get(project_id)


def toggle_task(project_id, task_id, completed):
    p = get_project(project_id)
    if not p:
        return None
    for task in p.get("tasks") or []:
        if str(task.get("id")) == str(task_id):
            task["completed"] = bool(completed)
            return task
    return None


def _set_stage(project, key, status):
    for s in project["stages"]:
        if s["key"] == key:
            s["status"] = status


def _reasoning_stage(project, role, prompt):
    """Route one reasoning stage through Band, falling back to the Model Gateway."""
    marker = f"[scene:{project['id'][:8]}]"
    if band_client.band_configured():
        try:
            raw = band_client.run_band_stage(role, prompt, marker)
            return parse_json_loose(raw)
        except Exception as err:
            print(f'[Pipeline] Band stage "{role}" fell back to Model Gateway: {err}', flush=True)
            project["band_fallbacks"] = project.get("band_fallbacks", 0) + 1
    return parse_json_loose(insforge_client.text_chat(prompt))


def create_project(image_bytes, image_mime, prefs):
    if demo_mode() or not insforge_client.insforge_configured():
        if not demo_mode():
            print("[Pipeline] InsForge not configured — serving demo experience instead.", flush=True)
        demo = build_demo_project()
        demo["id"] = "demo"
        with _lock:
            _projects["demo"] = demo
        return demo

    project_id = str(uuid.uuid4())
    project = {
        "id": project_id,
        "demo": False,
        "status": "processing",
        **prefs,
        "original_image_url": None,
        "generated_image_url": None,
        "room_analysis": None,
        "design": None,
        "products": [],
        "setup_guide": [],
        "tasks": [],
        "estimated_total": 0,
        "essential_subtotal": 0,
        "optional_subtotal": 0,
        "stages": [{**s, "status": "pending"} for s in copy.deepcopy(STAGE_DEFS)],
        "error": None,
    }
    with _lock:
        _projects[project_id] = project

    # Step 1 of the flow happens synchronously: store the original room image.
    upload = insforge_client.upload_image("room-images", image_bytes, image_mime)
    project["original_image_url"] = upload["url"]
    project["original_image_key"] = upload["key"]

    try:
        insforge_client.insert_project({
            "id": project_id,
            "party_type": prefs.get("party_type"),
            "theme": prefs.get("theme"),
            "colors": prefs.get("colors"),
            "guest_count": prefs.get("guest_count"),
            "budget": prefs.get("budget"),
            "event_date": prefs.get("event_date"),
            "additional_notes": prefs.get("notes"),
            "original_image_url": upload["url"],
            "status": "processing",
        })
    except Exception as err:
        print(f"[Pipeline] project row not saved (continuing in memory): {err}", flush=True)

    threading.Thread(target=_run_pipeline_safe, args=(project, prefs), daemon=True).start()
    return project


def _run_pipeline_safe(project, prefs):
    try:
        _run_pipeline(project, prefs)
    except Exception as err:
        print(f"[Pipeline] fatal: {err}", flush=True)
        project["status"] = "error"
        project["error"] = (
            "We hit a snag generating this party. Your room photo is saved — "
            "try again, or open the demo to see the full experience."
        )


def _run_pipeline(project, prefs):
    # Stage 1 — Room analysis. Perception via Model Gateway, structuring via Band analyst.
    _set_stage(project, "room_analysis", "active")
    vision_text = insforge_client.vision_chat(room_vision_prompt(), project["original_image_url"])
    project["room_analysis"] = _reasoning_stage(project, "analyst", room_analysis_prompt(vision_text))
    _set_stage(project, "room_analysis", "complete")
    _safe_update(project, {"room_analysis": project["room_analysis"]})

    # Stage 2 — Decoration plan (Band: Party Designer).
    _set_stage(project, "design_plan", "active")
    project["design"] = _reasoning_stage(project, "designer", design_plan_prompt(project["room_analysis"], prefs))
    _set_stage(project, "design_plan", "complete")

    # Stage 3 — The wow moment: edit THIS room into the finished party.
    _set_stage(project, "image_generation", "active")
    edited_png = insforge_client.generate_party_image(
        image_edit_prompt(prefs, project["design"]), project["original_image_url"]
    )
    gen_upload = insforge_client.upload_image("generated-images", edited_png, "image/png")
    project["generated_image_url"] = gen_upload["url"]
    _set_stage(project, "image_generation", "complete")
    _safe_update(project, {"generated_image_url": gen_upload["url"]})

    # Stage 4 — Visual inventory of what actually appears in the generated image.
    _set_stage(project, "visual_inventory", "active")
    decor_text = insforge_client.vision_chat(generated_image_vision_prompt(), project["generated_image_url"])
    inventory = _reasoning_stage(project, "inventory", visual_inventory_prompt(decor_text, prefs))
    _set_stage(project, "visual_inventory", "complete")
    _safe_update(project, {"visual_inventory": inventory})

    # Stage 5 — Prices, match scores, Amazon links (Band: Shopping Match).
    _set_stage(project, "product_matching", "active")
    matched = _reasoning_stage(project, "shopper", product_match_prompt(inventory, prefs))
    linked = with_amazon_links(matched if isinstance(matched, list) else inventory)
    project["products"] = []
    for i, p in enumerate(linked):
        score = p.get("matchScore", 80)
        project["products"].append({
            "id": f"{project['id']}-p{i + 1}",
            **p,
            "essential": str(p.get("importance", "")).lower() == "essential",
            "estimatedPrice": float(p.get("estimatedPrice") or 0),
            "matchScore": max(0, min(100, round(score if isinstance(score, (int, float)) else 80))),
        })
    recompute_totals(project)
    _set_stage(project, "product_matching", "complete")
    try:
        insforge_client.insert_products([
            {
                "project_id": project["id"],
                "item_name": p.get("name"),
                "category": p.get("category"),
                "search_query": p.get("search_query"),
                "amazon_url": p.get("amazon_url"),
                "estimated_price": p.get("estimatedPrice"),
                "quantity": p.get("estimatedQuantity") or 1,
                "match_score": p.get("matchScore"),
                "essential": p.get("essential"),
                "reasoning": p.get("reasoning") or "",
            }
            for p in project["products"]
        ])
    except Exception as err:
        print(f"[Pipeline] products not saved (continuing): {err}", flush=True)

    # Stage 6 — Room-specific setup guide + external checklist (Band: Setup Planner).
    _set_stage(project, "setup_plan", "active")
    plan = _reasoning_stage(
        project, "planner",
        setup_plan_prompt(project["room_analysis"], project["design"], project["products"]),
    )
    project["setup_guide"] = plan.get("setupGuide") or []
    project["tasks"] = [
        {
            "id": f"{project['id']}-t{i + 1}",
            **t,
            "sort_order": t.get("sort_order", i + 1),
            "completed": False,
        }
        for i, t in enumerate(plan.get("checklist") or [])
    ]
    _set_stage(project, "setup_plan", "complete")
    try:
        saved = insforge_client.insert_tasks([
            {
                "project_id": project["id"],
                "task": t.get("task"),
                "category": t.get("category"),
                "completed": False,
                "sort_order": t.get("sort_order"),
            }
            for t in project["tasks"]
        ])
        if isinstance(saved, list) and saved and saved[0].get("id"):
            for i, t in enumerate(project["tasks"]):
                if i < len(saved) and saved[i].get("id"):
                    t["id"] = saved[i]["id"]
    except Exception as err:
        print(f"[Pipeline] tasks not saved (continuing): {err}", flush=True)

    project["status"] = "complete"
    _safe_update(project, {"status": "complete", "estimated_total": project["estimated_total"]})
    print(f"[Pipeline] project {project['id']} complete ({project.get('band_fallbacks', 0)} Band fallbacks)", flush=True)


def recompute_totals(project):
    def total(items):
        return round(sum(float(p.get("estimatedPrice") or 0) for p in items), 2)

    products = project["products"]
    project["essential_subtotal"] = total([p for p in products if p.get("essential")])
    project["optional_subtotal"] = total([p for p in products if not p.get("essential")])
    project["estimated_total"] = round(project["essential_subtotal"] + project["optional_subtotal"], 2)


def _safe_update(project, patch):
    if project.get("demo") or not insforge_client.insforge_configured():
        return
    try:
        insforge_client.update_project(project["id"], patch)
    except Exception as err:
        print(f"[Pipeline] DB update skipped: {err}", flush=True)
