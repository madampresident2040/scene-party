"""Amazon search links built from the visual inventory of the GENERATED image.
Format required by spec: https://www.amazon.com/s?k=ENCODED_SEARCH_QUERY
No scraping — search result pages only."""

from urllib.parse import quote


def amazon_search_url(search_query):
    q = str(search_query or "").strip()
    if not q:
        return "https://www.amazon.com/s?k=party+decorations"
    return f"https://www.amazon.com/s?k={quote(q)}"


def with_amazon_links(products):
    """Attach amazon_url to every product; guarantee no vague queries slip through."""
    out = []
    for p in products or []:
        query = p.get("searchQuery") or p.get("search_query") or p.get("name") or ""
        # Guard: if a stage produced something too vague, enrich it from attributes.
        if len(query.strip().split()) < 3:
            parts = list((p.get("colors") or [])[:2])
            parts.append(p.get("style") or "")
            parts.append(p.get("name") or p.get("category") or "party decoration")
            query = " ".join(x for x in parts if x)
        out.append({**p, "search_query": query, "amazon_url": amazon_search_url(query)})
    return out
