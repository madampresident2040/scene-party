"""InsForge integration over its documented REST API (docs.insforge.dev):

  Storage        POST  /api/storage/buckets/{bucket}/objects   (multipart: file, path)
  Database       GET/POST/PATCH /api/database/records/{table}  (PostgREST syntax)
  Model Gateway  POST  /api/ai/chat/completions                (OpenAI-compatible)

All calls happen server-side; the browser never sees keys. The Model Gateway
routes to OpenRouter models — image generation is delivered through the
chat-completions endpoint for multimodal image models, with the uploaded room
passed as an input image so the model edits THIS room rather than inventing
a venue.
"""

import base64
import os
import uuid

import requests

VISION_MODEL = os.getenv("VISION_MODEL", "anthropic/claude-sonnet-4.5")
TEXT_MODEL = os.getenv("TEXT_MODEL", "anthropic/claude-3.5-haiku")
IMAGE_MODEL = os.getenv("IMAGE_MODEL", "google/gemini-3-pro-image-preview")

_TIMEOUT = 180


def _base_url():
    return (os.getenv("INSFORGE_BASE_URL") or "").rstrip("/")


def _anon_key():
    return os.getenv("INSFORGE_ANON_KEY") or ""


def insforge_configured():
    base = _base_url()
    return bool(base and _anon_key() and "your-project" not in base)


def _headers(extra=None):
    h = {"Authorization": f"Bearer {_anon_key()}"}
    if extra:
        h.update(extra)
    return h


def _require():
    if not insforge_configured():
        raise RuntimeError(
            "InsForge is not configured. Set INSFORGE_BASE_URL and INSFORGE_ANON_KEY in .env"
        )


def _raise_for(resp, what):
    if not resp.ok:
        raise RuntimeError(f"[InsForge] {what} failed ({resp.status_code}): {resp.text[:300]}")


# ── Storage ──────────────────────────────────────────────────────────
_EXT = {"image/jpeg": "jpg", "image/png": "png", "image/webp": "webp"}


def upload_image(bucket, data, mime_type):
    _require()
    ext = _EXT.get(mime_type or "image/png", "png")
    key = f"scene/{uuid.uuid4().hex}.{ext}"
    resp = requests.post(
        f"{_base_url()}/api/storage/buckets/{bucket}/objects",
        headers=_headers(),
        data={"path": key},
        files={"file": (key.split("/")[-1], data, mime_type or "image/png")},
        timeout=_TIMEOUT,
    )
    _raise_for(resp, f'Storage upload to "{bucket}"')
    out = resp.json()
    url = out.get("url") or f"{_base_url()}/api/storage/buckets/{bucket}/objects/{out.get('key', key)}"
    print(f"[InsForge Storage] uploaded {out.get('key', key)} → {url}", flush=True)
    return {"key": out.get("key", key), "url": url}


# ── Database (PostgREST) ─────────────────────────────────────────────
def _db(table):
    return f"{_base_url()}/api/database/records/{table}"


def _insert(table, rows):
    _require()
    if not rows:
        return []
    resp = requests.post(
        _db(table),
        headers=_headers({"Content-Type": "application/json", "Prefer": "return=representation"}),
        json=rows,
        timeout=_TIMEOUT,
    )
    _raise_for(resp, f"insert {table}")
    try:
        return resp.json()
    except ValueError:
        return rows


def _update(table, row_id, patch):
    _require()
    resp = requests.patch(
        f"{_db(table)}?id=eq.{row_id}",
        headers=_headers({"Content-Type": "application/json"}),
        json=patch,
        timeout=_TIMEOUT,
    )
    _raise_for(resp, f"update {table}")


def insert_project(row):
    saved = _insert("party_projects", [row])
    return saved[0] if isinstance(saved, list) and saved else row


def update_project(project_id, patch):
    _update("party_projects", project_id, patch)


def insert_products(rows):
    return _insert("party_products", rows)


def insert_tasks(rows):
    return _insert("party_tasks", rows)


def set_task_completed(task_id, completed):
    _update("party_tasks", task_id, {"completed": bool(completed)})


# ── Model Gateway ────────────────────────────────────────────────────
def _chat(payload):
    _require()
    resp = requests.post(
        f"{_base_url()}/api/ai/chat/completions",
        headers=_headers({"Content-Type": "application/json"}),
        json=payload,
        timeout=_TIMEOUT,
    )
    _raise_for(resp, f"Model Gateway chat ({payload.get('model')})")
    return resp.json()


def vision_chat(prompt, image_url):
    out = _chat({
        "model": VISION_MODEL,
        "messages": [{
            "role": "user",
            "content": [
                {"type": "text", "text": prompt},
                {"type": "image_url", "image_url": {"url": image_url}},
            ],
        }],
    })
    return out["choices"][0]["message"]["content"]


def text_chat(prompt):
    out = _chat({
        "model": TEXT_MODEL,
        "messages": [{"role": "user", "content": prompt}],
    })
    return out["choices"][0]["message"]["content"]


def _decode_image_payload(value):
    """Accept either a raw base64 string or a data:image/...;base64,... URI."""
    s = str(value or "")
    if s.startswith("data:"):
        s = s.split(",", 1)[-1]
    return base64.b64decode(s)


def generate_party_image(prompt, source_image_url):
    """Image-to-image: the uploaded room is an input image, so the model edits
    THIS room. InsForge's gateway delivers image generation through the
    chat-completions endpoint for multimodal image models; the generated image
    comes back in the assistant message's `images` array (OpenRouter's
    extended format), with `data[].b64_json` handled as a fallback shape."""
    out = _chat({
        "model": IMAGE_MODEL,
        "messages": [{
            "role": "user",
            "content": [
                {"type": "text", "text": prompt},
                {"type": "image_url", "image_url": {"url": source_image_url}},
            ],
        }],
        "modalities": ["image", "text"],
    })

    message = (out.get("choices") or [{}])[0].get("message") or {}
    for img in message.get("images") or []:
        url = ((img or {}).get("image_url") or {}).get("url")
        if url:
            return _decode_image_payload(url)

    for item in out.get("data") or []:
        if item.get("b64_json"):
            return _decode_image_payload(item["b64_json"])

    raise RuntimeError("[InsForge Model Gateway] image model returned no image data")
