"""Scene's Band specialist agents.

Five remote agents connect to the Band platform using the documented
Band SDK pattern (docs.band.ai → Integrations → SDKs → Anthropic Adapter):
each is created with `Agent.create(adapter=AnthropicAdapter(...), ...)`,
wakes when @mentioned in the Scene chat room, and replies by @mentioning
@SceneOrchestrator (the Scene server) with its JSON result.

Setup (see README "Band" section):
  1. Register five Remote Agents at https://app.band.ai/agents:
     SceneAnalyst, SceneDesigner, SceneInventory, SceneShopper, ScenePlanner
     (plus SceneOrchestrator, whose key goes in the server's .env).
  2. Create one chat room in the Band UI and add all six as participants.
  3. Fill agent_config.yaml (copy agent_config.yaml.example) and .env.
  4. uv add "band-sdk[anthropic]" python-dotenv
  5. uv run python agents.py
"""

import asyncio
import logging
import os

from dotenv import load_dotenv
from band import Agent
from band.adapters import AnthropicAdapter
from band.config import load_agent_config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("scene.band")

MODEL = os.getenv("BAND_AGENT_MODEL", "claude-sonnet-4-5")

SHARED_RULES = """
You are one specialist in Scene's party-planning pipeline. The Scene
Orchestrator sends you work as a message that includes a marker like
[scene:abc12345] and ends with reply instructions.

Rules:
- Do the task using ONLY the data in the message. Do not invent room
  features or decorations that were not described.
- Reply exactly once, using the band_send_message tool, mentioning
  @SceneOrchestrator.
- Your reply must be: the marker on the first line, then ONLY the JSON
  requested — no markdown fences, no commentary.
- Do not @mention any other agent. After replying, stay silent until
  you are mentioned again.
"""

ROLE_PROMPTS = {
    "scene_analyst": SHARED_RULES + """
Role: Room Analysis Agent. You turn a factual description of an uploaded
room photo into structured room-analysis JSON with the exact keys the
orchestrator specifies. Be conservative: only surfaces and locations that
were actually described.
""",
    "scene_designer": SHARED_RULES + """
Role: Party Designer Agent. You design a realistic, purchasable decoration
plan for the specific room analysis and party preferences you receive.
Every decoration must be placed at a real location from the analysis.
""",
    "scene_inventory": SHARED_RULES + """
Role: Visual Inventory Agent. You convert a description of decorations
visible in the GENERATED party image into a structured shopping inventory.
Only items that appear in the description. Search queries must be precise:
colors + item + size or count. Never a vague query like "party decoration".
""",
    "scene_shopper": SHARED_RULES + """
Role: Shopping Match Agent. You price each inventory item realistically in
USD and score how well an Amazon search for it would match the generated
design: color similarity, category, style, size, budget fit, importance.
Scores are 0-100 integers and must be consistent across items.
""",
    "scene_planner": SHARED_RULES + """
Role: Setup Planner Agent. You write room-specific setup steps that name
the actual room features and actual products (never generic instructions),
plus an external party checklist. Order steps so large anchors (backdrop,
arch) go up before tabletop styling.
""",
}


async def run_role(config_key: str) -> None:
    agent_id, api_key = load_agent_config(config_key)
    adapter = AnthropicAdapter(
        model=MODEL,
        prompt=ROLE_PROMPTS[config_key],
        max_tokens=8192,
    )
    agent = Agent.create(
        adapter=adapter,
        agent_id=agent_id,
        api_key=api_key,
        ws_url=os.getenv("BAND_WS_URL", "wss://app.band.ai/api/v1/socket/websocket"),
        rest_url=os.getenv("BAND_REST_URL", "https://app.band.ai"),
    )
    logger.info("Starting %s (%s)", config_key, agent_id)
    await agent.run()


async def main() -> None:
    load_dotenv()
    roles = list(ROLE_PROMPTS)
    logger.info("Scene Band crew starting: %s", ", ".join(roles))
    await asyncio.gather(*(run_role(r) for r in roles))


if __name__ == "__main__":
    asyncio.run(main())
