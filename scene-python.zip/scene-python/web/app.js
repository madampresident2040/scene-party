/* Scene frontend — vanilla JS, no frameworks. */
(() => {
  'use strict';

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
  const views = ['landing', 'wizard', 'loading', 'dashboard'];

  const state = { file: null, project: null, poll: null, celebrated: false };

  function show(view) {
    views.forEach((v) => { $(`#view-${v}`).hidden = v !== view; });
    window.scrollTo({ top: 0 });
  }

  /* ── Chip groups ─────────────────────────────────────────────── */
  const PARTY_TYPES = ['Birthday', 'Graduation', 'Baby shower', 'Gender reveal', 'Anniversary', 'Holiday party', 'Wedding event', 'Character party', 'Themed party', 'Custom event'];
  const STYLES = ['Elegant', 'Luxury', 'Minimal', 'Boho', 'Modern', 'Floral', 'Colorful', 'Disco', 'Rustic', 'Character themed'];
  const COLORS = [
    ['Sage green', '#9caf88'], ['Gold', '#d8b75a'], ['Blush pink', '#f2b8c6'],
    ['White', '#f5f2ec'], ['Navy', '#31446c'], ['Lavender', '#b9a7e0'],
    ['Terracotta', '#c96f4a'], ['Teal', '#3e8f8a'], ['Silver', '#c9ccd4'], ['Black', '#2a2a2f'],
  ];

  function buildChips(rootId, items, { multi = false, def = [] } = {}) {
    const root = $(rootId);
    items.forEach((item) => {
      const [label, swatch] = Array.isArray(item) ? item : [item, null];
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'chip';
      b.dataset.value = label;
      b.innerHTML = swatch ? `<span class="chip-swatch" style="background:${swatch}"></span>${label}` : label;
      if (def.includes(label)) b.classList.add('is-on');
      b.addEventListener('click', () => {
        if (multi) b.classList.toggle('is-on');
        else { $$('.chip', root).forEach((c) => c.classList.remove('is-on')); b.classList.add('is-on'); }
      });
      root.appendChild(b);
    });
  }
  buildChips('#chips-type', PARTY_TYPES, { def: ['Graduation'] });
  buildChips('#chips-style', STYLES, { def: ['Elegant'] });
  buildChips('#chips-colors', COLORS, { multi: true, def: ['Sage green', 'Gold', 'White'] });
  $$('#chips-setting .chip').forEach((b) => b.addEventListener('click', () => {
    $$('#chips-setting .chip').forEach((c) => c.classList.remove('is-on'));
    b.classList.add('is-on');
  }));

  const picked = (rootId) => $$(`.chip.is-on`, $(rootId)).map((c) => c.dataset.value);

  /* ── Upload ──────────────────────────────────────────────────── */
  const dz = $('#dropzone');
  const input = $('#room-input');
  function acceptFile(file) {
    if (!file) return;
    if (!/image\/(jpeg|png|webp)/.test(file.type)) { showError('Please choose a JPG, PNG, or WebP photo.'); return; }
    if (file.size > 12 * 1024 * 1024) { showError('That photo is over 12 MB — try a smaller one.'); return; }
    state.file = file;
    const url = URL.createObjectURL(file);
    const img = $('#room-preview');
    img.src = url; img.hidden = false;
    $('#dz-empty').hidden = true;
    showError('');
  }
  input.addEventListener('change', () => acceptFile(input.files[0]));
  ['dragover', 'dragenter'].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add('is-over'); }));
  ['dragleave', 'drop'].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.remove('is-over'); }));
  dz.addEventListener('drop', (e) => acceptFile(e.dataTransfer.files[0]));

  function showError(msg) {
    const el = $('#wizard-error');
    el.textContent = msg; el.hidden = !msg;
  }

  /* ── Generate ────────────────────────────────────────────────── */
  $('#btn-generate').addEventListener('click', async () => {
    const btn = $('#btn-generate');
    const prefs = {
      party_type: picked('#chips-type')[0] || 'Birthday',
      style: picked('#chips-style')[0] || 'Elegant',
      colors: picked('#chips-colors'),
      setting: picked('#chips-setting')[0] || 'indoor',
      guest_count: $('#f-guests').value,
      budget: $('#f-budget').value,
      event_date: $('#f-date').value || null,
      theme: $('#f-theme').value,
      wants: $('#f-wants').value,
      avoids: $('#f-avoids').value,
      notes: $('#f-notes').value,
    };
    const body = new FormData();
    if (state.file) body.append('room', state.file);
    body.append('prefs', JSON.stringify(prefs));

    btn.disabled = true; btn.textContent = 'Starting…';
    try {
      const res = await fetch('/api/projects', { method: 'POST', body });
      const project = await res.json();
      if (!res.ok) throw new Error(project.error || 'Could not start your project.');
      state.project = project;
      state.celebrated = false;
      if (project.status === 'complete') renderDashboard(project);
      else { startLoading(project); pollProject(project.id); }
    } catch (err) {
      showError(err.message);
    } finally {
      btn.disabled = false; btn.textContent = 'Generate my party vision';
    }
  });

  /* ── Loading sequence ────────────────────────────────────────── */
  const LOAD_LINES = [
    'Uploading your room', 'Understanding the space', 'Designing your party',
    'Identifying decorations', 'Finding matching products', 'Building your setup plan',
  ];
  function startLoading(project) {
    show('loading');
    const ol = $('#loading-steps');
    ol.innerHTML = '';
    (project.stages || []).forEach((s) => {
      const li = document.createElement('li');
      li.dataset.key = s.key;
      li.textContent = s.done;
      ol.appendChild(li);
    });
    updateLoading(project);
  }
  function updateLoading(project) {
    let activeLabel = LOAD_LINES[0];
    (project.stages || []).forEach((s) => {
      const li = $(`#loading-steps li[data-key="${s.key}"]`);
      if (!li) return;
      li.classList.toggle('is-done', s.status === 'complete');
      li.classList.toggle('is-active', s.status === 'active');
      if (s.status === 'active') activeLabel = s.label;
    });
    $('#loading-line').textContent = activeLabel;
  }

  function pollProject(id) {
    clearInterval(state.poll);
    state.poll = setInterval(async () => {
      try {
        const res = await fetch(`/api/projects/${id}`);
        if (!res.ok) throw new Error('lost');
        const p = await res.json();
        state.project = p;
        if (p.status === 'complete') { clearInterval(state.poll); renderDashboard(p); }
        else if (p.status === 'error') { clearInterval(state.poll); showFailure(p.error); }
        else updateLoading(p);
      } catch { /* transient network blip — keep polling */ }
    }, 2500);
  }

  function showFailure(msg) {
    show('wizard');
    showError(msg || 'Something went wrong. Try again, or open the demo experience.');
  }

  /* ── Before/after slider ─────────────────────────────────────── */
  function wireSlider(el) {
    const set = (frac) => {
      const f = Math.min(0.98, Math.max(0.02, frac));
      el.style.setProperty('--split', `${f * 100}%`);
      el.style.setProperty('--split-frac', f);
    };
    set(0.5);
    let dragging = false;
    const fromEvent = (e) => {
      const rect = el.getBoundingClientRect();
      const x = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
      set(x / rect.width);
    };
    el.addEventListener('pointerdown', (e) => { dragging = true; el.setPointerCapture(e.pointerId); fromEvent(e); });
    el.addEventListener('pointermove', (e) => dragging && fromEvent(e));
    el.addEventListener('pointerup', () => { dragging = false; });
  }
  wireSlider($('#hero-ba'));

  /* ── Dashboard ───────────────────────────────────────────────── */
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = (n) => `$${Number(n || 0).toFixed(2)}`;

  const GROUP_ORDER = ['Backdrop and focal area', 'Balloons and wall decor', 'Tablescape', 'Lighting', 'Cake and dessert table', 'Party favors', 'Optional upgrades'];

  function renderDashboard(p) {
    show('dashboard');
    const root = $('#dash-root');
    const visible = (p.products || []).filter((x) => !x.hidden);
    const groups = GROUP_ORDER.map((g) => [g, visible.filter((x) => x.category === g)]).filter(([, list]) => list.length);
    const remaining = (p.budget || 0) - (p.estimated_total || 0);
    const palette = p.design?.colorPalette || [];

    root.innerHTML = `
      ${p.demo ? '<div class="demo-banner">Sample project — this is Scene\u2019s bundled demo room and result. Connect InsForge to generate from your own photo.</div>' : ''}

      <section class="dash-section">
        <h2>${esc(p.design?.partyName || p.theme || 'Your party vision')}</h2>
        <p class="dash-sub">${esc(p.design?.designExplanation || '')}</p>
        <div class="vision-grid">
          <figure class="hero-slider" style="margin:0">
            <div class="ba-slider" id="dash-ba">
              <button class="ba-full" data-action="fullscreen">View full screen</button>
              <img class="ba-after" src="${esc(p.generated_image_url)}" alt="Your room decorated as the AI party vision" />
              <div class="ba-before-wrap"><img class="ba-before" src="${esc(p.original_image_url)}" alt="Your original room" /></div>
              <div class="ba-seam" aria-hidden="true"><span class="ba-handle">↔</span></div>
              <span class="ba-tag ba-tag-left">Original room</span>
              <span class="ba-tag ba-tag-right">AI party vision</span>
            </div>
          </figure>
          <div class="vision-meta">
            <div class="meta-card">
              <h3>Color palette</h3>
              <p>${esc((p.design?.paletteNames || p.colors || []).join(' · '))}</p>
              <div class="palette">${palette.map((c) => `<span style="background:${esc(c)}"></span>`).join('')}</div>
            </div>
            <div class="meta-card">
              <h3>Estimated total</h3>
              <div class="total-line">${money(p.estimated_total)}</div>
              <p>${esc(String(visible.length))} decorations · ${esc(String(p.guest_count))} guests · ${esc(p.party_type || '')}</p>
            </div>
            <div class="meta-card">
              <h3>The room, read by Scene</h3>
              <p>${esc(p.room_analysis?.recommendedStrategy || '')}</p>
            </div>
          </div>
        </div>
      </section>

      <section class="dash-section">
        <h2>Shop this look</h2>
        <p class="dash-sub">Every item below was identified in your generated vision — each button opens a live Amazon search for it.</p>
        ${groups.map(([g, list]) => `
          <div class="shop-group">
            <h3>${esc(g)}</h3>
            <div class="product-grid">
              ${list.map((x) => `
                <article class="product">
                  <div class="badge-row">
                    <span class="badge ${x.essential ? 'badge-essential' : ''}">${x.essential ? 'Essential' : 'Optional'}</span>
                    <span class="badge badge-match">${esc(String(x.matchScore))}% visual match</span>
                  </div>
                  <h4>${esc(x.name)}</h4>
                  <div class="p-meta">${esc((x.colors || []).join(', '))} · qty ${esc(String(x.estimatedQuantity || 1))} · ${esc(x.roomLocation || '')}</div>
                  <p class="p-why">${esc(x.reasoning || '')}</p>
                  <div class="p-price">${money(x.estimatedPrice)}</div>
                  <a class="p-shop" href="${esc(x.amazon_url)}" target="_blank" rel="noopener">Shop on Amazon ↗</a>
                </article>`).join('')}
            </div>
          </div>`).join('')}
      </section>

      <section class="dash-section">
        <h2>Budget</h2>
        <div class="budget-grid">
          <div class="budget-card"><div class="b-label">Your budget</div><div class="b-value">${money(p.budget)}</div></div>
          <div class="budget-card"><div class="b-label">Estimated decor</div><div class="b-value">${money(p.estimated_total)}</div></div>
          <div class="budget-card"><div class="b-label">Remaining</div><div class="b-value ${remaining < 0 ? 'b-over' : 'b-under'}">${money(remaining)}</div></div>
          <div class="budget-card"><div class="b-label">Essentials</div><div class="b-value">${money(p.essential_subtotal)}</div></div>
          <div class="budget-card"><div class="b-label">Optional</div><div class="b-value">${money(p.optional_subtotal)}</div></div>
        </div>
        <div class="budget-actions">
          <button class="btn btn-ghost" data-budget="under_budget">Stay under budget</button>
          <button class="btn btn-ghost" data-budget="fewer">Show fewer products</button>
          <button class="btn btn-ghost" data-budget="replace_expensive">Trim expensive items</button>
          <button class="btn btn-ghost" data-budget="essentials">Prioritize essentials</button>
          <button class="btn btn-ghost" data-budget="reset">Show everything</button>
        </div>
      </section>

      <section class="dash-section">
        <h2>Setup guide</h2>
        <p class="dash-sub">Written for your room — each step references the actual layout Scene analyzed.</p>
        <div class="setup-list">
          ${(p.setup_guide || []).map((s) => `
            <div class="setup-step">
              <div class="setup-num">${esc(String(s.step))}</div>
              <div>
                <p>${esc(s.instruction)}</p>
                <div class="s-meta">${esc(s.estimatedTime || '')} · ${esc(String(s.helpers || 1))} helper${(s.helpers || 1) > 1 ? 's' : ''}${(s.requiredProducts || []).length ? ' · uses: ' + esc(s.requiredProducts.join(', ')) : ''}</div>
              </div>
            </div>`).join('')}
        </div>
      </section>

      <section class="dash-section">
        <h2>Party checklist</h2>
        <div class="checklist">
          ${(p.tasks || []).map((t) => `
            <label class="check-item ${t.completed ? 'is-done' : ''}" data-task="${esc(String(t.id))}">
              <input type="checkbox" ${t.completed ? 'checked' : ''} />
              <span>${esc(t.task)}</span>
              <span class="c-cat">${esc(t.category || '')}</span>
            </label>`).join('')}
        </div>
      </section>

      <details class="pipeline">
        <summary>See how Scene planned this party</summary>
        <ul class="pipeline-stages">
          ${(p.stages || []).map((s) => `<li>${esc(s.done)} <span class="pl-agent">— ${esc(s.agent)}</span></li>`).join('')}
        </ul>
        <p class="powered">Planning workflow coordinated by <strong>Band</strong> agents · images, data, and AI models by <strong>InsForge</strong>.</p>
      </details>
    `;

    wireSlider($('#dash-ba'));

    $('[data-action="fullscreen"]').addEventListener('click', (e) => {
      e.stopPropagation();
      const box = document.createElement('div');
      box.className = 'lightbox';
      box.innerHTML = `<button class="btn btn-ghost">Close</button><img src="${esc(p.generated_image_url)}" alt="AI party vision, full screen" />`;
      box.addEventListener('click', () => box.remove());
      document.body.appendChild(box);
    });

    $$('[data-budget]').forEach((b) => b.addEventListener('click', async () => {
      const res = await fetch(`/api/projects/${p.id}/budget`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: b.dataset.budget }),
      });
      if (res.ok) renderDashboard(await res.json());
    }));

    $$('.check-item').forEach((label) => {
      const box = $('input', label);
      box.addEventListener('change', async () => {
        label.classList.toggle('is-done', box.checked);
        await fetch(`/api/projects/${p.id}/tasks/${label.dataset.task}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ completed: box.checked }),
        }).catch(() => {});
      });
    });

    if (!state.celebrated) { state.celebrated = true; confettiBurst(); }
  }

  /* ── Nav ─────────────────────────────────────────────────────── */
  $$('[data-nav]').forEach((b) => b.addEventListener('click', () => show(b.dataset.nav)));
  $$('[data-action="demo"]').forEach((b) => b.addEventListener('click', async () => {
    b.disabled = true;
    try {
      const res = await fetch('/api/demo');
      const p = await res.json();
      state.project = p; state.celebrated = false;
      renderDashboard(p);
    } finally { b.disabled = false; }
  }));

  /* ── Confetti (brief, respects reduced motion) ───────────────── */
  function confettiBurst() {
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const canvas = $('#confetti');
    const ctx = canvas.getContext('2d');
    canvas.width = innerWidth; canvas.height = innerHeight;
    const colors = ['#f2cf8b', '#ff7d8c', '#c46bd8', '#f7f5fb'];
    const bits = Array.from({ length: 140 }, () => ({
      x: innerWidth / 2 + (Math.random() - 0.5) * 200,
      y: innerHeight * 0.28,
      vx: (Math.random() - 0.5) * 11,
      vy: -Math.random() * 10 - 3,
      r: Math.random() * 5 + 2.5,
      c: colors[(Math.random() * colors.length) | 0],
      a: Math.random() * Math.PI,
    }));
    const t0 = performance.now();
    (function frame(t) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      bits.forEach((b) => {
        b.vy += 0.22; b.x += b.vx; b.y += b.vy; b.a += 0.15;
        ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(b.a);
        ctx.fillStyle = b.c; ctx.fillRect(-b.r, -b.r / 2, b.r * 2, b.r);
        ctx.restore();
      });
      if (t - t0 < 2400) requestAnimationFrame(frame);
      else ctx.clearRect(0, 0, canvas.width, canvas.height);
    })(t0);
  }
})();
